USE Shumabo_secondary_school

--Login 1: Create System_Admin login

    CREATE LOGIN System_Admin WITH PASSWORD = 'sysadmin1234';


--Login 2: Create Director login

    CREATE LOGIN Director WITH PASSWORD = 'director1234';


--Login 3: Create Teacher login

    CREATE LOGIN Teacher WITH PASSWORD = 'teacher1234';


--Login 4: Create Staff login

    CREATE LOGIN Staffs WITH PASSWORD = 'staff1234';


--Login 5: Create Resource Officer login

    CREATE LOGIN Resource_officer WITH PASSWORD = 'RO1234';


--Login 6: Create Registrar login

    CREATE LOGIN Registrar WITH PASSWORD = 'registrar1234';


--Login 7: create Unit_leader login

    CREATE LOGIN Unit_leader WITH  PASSWORD = 'UL1234'


-- Login 8: Create a Security_admin login

CREATE Login Security_Admin WITH PASSWORD = 'secadmin1234'

