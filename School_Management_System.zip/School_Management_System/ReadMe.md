# School Management System 

This is a School Management System With T-SQL, it contains:-
    <ul>
        <li> Full <b> <a href="#">Documentation</a> </b> with detail expanation and diagram representation </li>
        <li> Full <b><a href="https://github.com/sgc93/School-Management-System/tree/main/T-SQL">T-SQL code</a></b> with different sql files so that it will be good for some sort of managing. </li>
    </ul>
